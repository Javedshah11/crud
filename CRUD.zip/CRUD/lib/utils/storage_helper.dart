import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class StorageHelper {
  Future<String> get _localPath async {
    final directory = await getApplicationDocumentsDirectory();
    return directory.path;
  }

  Future<File> get _userFile async {
    final path = await _localPath;
    return File('$path/user.txt');
  }

  Future<void> registerUser(String username, String password) async {
    final file = await _userFile;
    await file.writeAsString('$username:$password');
  }

  Future<bool> validateCredentials(String username, String password) async {
    final file = await _userFile;
    if (!await file.exists()) return false;

    String content = await file.readAsString();
    List<String> parts = content.split(':');
    return parts.length == 2 && parts[0] == username && parts[1] == password;
  }

  Future<void> saveLogin(String username) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isLoggedIn', true);
    await prefs.setString('username', username);
  }

  Future<void> logout() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }
}
