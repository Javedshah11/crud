import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/note.dart';

class NoteService {
  static const String notesKey = 'notes';

  Future<List<Note>> getNotes() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? rawNotes = prefs.getStringList(notesKey);
    return rawNotes?.map((e) => Note.fromJson(jsonDecode(e))).toList() ?? [];
  }

  Future<void> saveNotes(List<Note> notes) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> encoded =
        notes.map((note) => jsonEncode(note.toJson())).toList();
    await prefs.setStringList(notesKey, encoded);
  }

  Future<void> addNote(Note note) async {
    List<Note> notes = await getNotes();
    notes.add(note);
    await saveNotes(notes);
  }

  Future<void> deleteNote(String id) async {
    List<Note> notes = await getNotes();
    notes.removeWhere((note) => note.id == id);
    await saveNotes(notes);
  }
}
