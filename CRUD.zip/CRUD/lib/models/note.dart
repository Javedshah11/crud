class Note {
  final String id;
  final String content;

  Note({
    required this.id,
    required this.content,
  });

  factory Note.fromJson(Map<String, dynamic> json) {
    return Note(
      id: json['id'],
      content: json['content'],
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'content': content,
      };
}
